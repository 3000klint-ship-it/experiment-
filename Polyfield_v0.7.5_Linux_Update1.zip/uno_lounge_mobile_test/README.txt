UNO Lounge — MOBILE-FIRST TEST BUILD

This version is optimized first for Android/iPhone browser screens, with desktop support retained.

Run:
1. Install Node.js 18+.
2. Open a terminal in this folder.
3. npm install
4. npm start
5. On the phone, open http://<LAPTOP-IP>:3000 while connected to the same network.

Mobile changes:
- Full-height mobile viewport and safe-area support
- Touch-sized buttons and controls
- Horizontal swipeable card hand
- Larger, easier-to-tap controls
- Compact 6/8-player table layout
- Landscape phone/tablet support
- Separate Draw button for easier touch use
- Desktop remains supported

Character photos are still placeholders until you provide the photos.
